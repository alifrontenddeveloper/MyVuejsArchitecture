<template>
  <section class="keeper-main-el">

    <main
      v-show="getDashboardShowContent"
      class="main-wrapper"
      :class="[
      wrapperClass,
      bgColorClass,
      {
        'active-sidebar': sidebarOpen,
        'loading-data': this.$store.state.loadingQueue > 0
      }
    ]"
    >
      <transition name="slide-right">
        <router-view
          ref="sidebarOver"
          name="right-sidebar-o"
          @toggleSidebar="toggleSidebar"
        />
      </transition>
      <transition name="slide-right" class="">
        <router-view ref="sidebar" name="right-sidebar"/>
      </transition>
      <transition name="slide-right" class="">
        <nav class="navbar navbar-default navbar-fixed-bottom hidden-md hidden-lg" style="background: #f9c700">
          <div class="container">
           
          </div>
        </nav>
      </transition>
      <div id="main" ref="container" :class="wrapperClass">
        <transition name="slide-down">
          <router-view
            ref="header"
            name="header"
            @toggleSidebar="toggleSidebar"
          />
        </transition>


        <transition name="app-scale">
          <keep-alive :include="config.includeKeepAliveRouters">
            <router-view class="router-base"/>
          </keep-alive>
        </transition>

        <!-- <transition name="fade-app">
          <router-view ref="footer" name="footer" />
        </transition> -->
      </div>
      <transition name="fade">
        <div
          v-if="this.$store.state.loadingQueue > 0"
          class="page-loader loading loading-primary loading-center"
        />
      </transition>
    </main>
  </section>
</template>

<script>
import {mapGetters} from 'vuex'
import HeaderPresentation from './components/pages/Presentation/header'

const triggerScroll = () => window.dispatchEvent(new Event('scroll'))
const triggerResize = () => window.dispatchEvent(new Event('resize'))

export default {
  name: 'App',
  components: {
    HeaderPresentation
  },
  data() {
    return {
      timeout: false,
      sidebarOpen: false,
      windowWidth: window.innerWidth,
      routerTransitionName: 'slide-left',
      sidebarBreakpoint: this.css.sidebarShowBreakpoint.replace('px', '') * 1
    }
  },
  computed: {
    ...mapGetters('dashboard', ['getAllDetails', 'getDashboardShowContent']),
    ...mapGetters('login', ['getCurrentUserLoginState']),
    //check routing show suitable class on route
    wrapperClass() {
      switch (this.$route.name) {
        case 'packageCode':
          return 'package-code-page'
        case '404':
          return 'page-404'
        case 'login':
          return 'login-register-page'
        case 'onbording':
          return 'login-register-page'
        case 'siteBlock':
          return 'Site-block'
        case 'gift':
          return 'Gift'
        // case 'CompletedUserInformation':
        //   return 'login-register-page'
        default:
          return ''
      }
    },
    //controller flag joon and is_active and is_graduated return suitable body background color
    bgColorClass() {
      //check is dismissal
      if (
        this.getAllDetails.has_joon == false &&
        this.getAllDetails.is_active == false
      )
        return 'bg-dismissal'

      //check is limited
      if (
        (this.getAllDetails.has_joon == true &&
          this.getAllDetails.is_active == false) ||
        (this.getAllDetails.has_joon == false &&
          this.getAllDetails.is_active == false)
      )
        return 'bg-limited'

      //check is graduated
      if (this.getAllDetails.graduated)
        return 'bg-limited'

      return 'bg-white'
    },
    //current user is completing user profile infocmation
    CurrentUserCompletingUserProfileInformation() {
      if (this.getAllDetails.hasOwnProperty('userProfile')) {
        return this.getAllDetails.userProfile.CurrentUserProfileInformationImperfect
      }
    },
    //check current user is login to system
    checkCurrentUserLoginToSystem() {
      return modules.actions.getToken();
    }
  },
  watch: {
    windowWidth(val) {
      this.toggleSidebar(val > this.sidebarBreakpoint)
    },
    '$route.name'(after, before) {
      let ac = ['register', 'login', 'onbording']
      if (ac.indexOf(after) !== -1 || ac.indexOf(before) !== -1) {
        this.routerTransitionName = 'slide-right'
      } else {
        this.routerTransitionName = 'slide-left'
      }
      this.toggleSidebar(false)
      setTimeout(triggerResize, 100)
    },

    //check show sidebar from dashboard show and hide
    '$store.state.dashboard.showSidebarFromChildrenToAppControl'(val) {
      if (val) this.toggleSidebar(val)
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.sidebarOpen = this.windowWidth > this.sidebarBreakpoint
      window.addEventListener('focus', triggerResize)
    })
    // update sticky and other listeners
    setInterval(triggerScroll, 1000)
  },
  created() {
    //check user token not null resolve =>> check user access to site
    if (typeof this.actions.getToken() !== 'undefined') {
      setInterval(() => {
        this.checkUserAccess()
      }, 60000)
    }
  },
  methods: {
    //sidebar controller and responsive handler steps
    toggleSidebar(show) {
      this.sidebarOpen = typeof show === 'boolean' ? show : !this.sidebarOpen
      if (this.sidebarOpen && this.windowWidth < this.sidebarBreakpoint + 1) {
        let x = window.scrollX
        let y = window.scrollY
        window.onscroll = () => window.scrollTo(x, y)
      } else {
        window.onscroll = () => {
        }
      }
    },
    //check user access to sites / dont user access redirect user to site block route
    checkUserAccess() {
      this.$store.dispatch('Global/checkUserAccess').then(response => {
        if (!response.isSuccess) {
          this.redirectToSiteBlock()
        } else if (this.$route.name == 'SiteBlock') {
          this.redirectToHome()
        }
      })
    },
    //passing user to site block route
    redirectToSiteBlock() {
      this.$router.push('/siteblock')
    },
    //passing user to dashboard route
    redirectToHome() {
      this.$router.push('/')
    }
  }
}
</script>

<style>
.package-code-page {
  background-color: #352e57 !important;
}

[v-cloak] {
  display: none;
}
nav.navbar a {
   color: #555;
 }
nav.navbar a.router-link-exact-active {
  color: #fff;
}
</style>
