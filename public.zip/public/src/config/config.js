import menu from './menu'
import {api} from './api'

export default {
  title: 'تست',
  pageTitle: 'تست | ',
  noneToken: ['login', 'register', 'surprise2'],
  includeKeepAliveRouters: ['login', 'register'],
  api,
  menu: menu,
  courceFrom: -5,
  courceEnd: 100,
  adminType: 10,
  endUserDay: 100,
  GuestUser: 100,
  userNotGetVacationInDay: [-5, -4, -3, -2, -1],
}
