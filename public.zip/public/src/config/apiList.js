export default {
  login: 'user_login/',
  //---------------------------------------
  comments: {
    create: 'comment/',
    edit: 'comment/',
    delete: 'comment/',
    list: 'comment_list/?day_related=',
    like: 'comment/',
    pinSingleComment: 'comment_pin/'
  },
  user: {
    notification: '/activity/?is_notification=OK',
    notificationArchiveList: 'activity_notification_list/?',
    notificationSeen: 'activity/',
    imageCropStart: 'FaceExtraction/',
    confirmUserImageCrop: 'FaceExtractionStatus/',
    updateUserInformation: 'profile/',
    userPostalCode: 'user_location_info/',
    notificationCounterZero: 'ActivityCounterToZero/',
    joonIncrement: 'short_joon_flag/',
    completeInformation: "update_profile",
    completeInformationPost: "update_postal_code/",
    currentUserUniqKeyAutoLogin: 'auto_login_check/?',
    presentationUserGetCode: 'send_login_code/',
    presentationUserRegisterCode: 'login_with_code/',
    registerUserGuestInformation: 'give_info_any_user/',
    miniProfile: 'user_mini_profile/?owner_id=',
    getCurrentUserDead_line: 'dead_line/',
    registerReportCard: 'user_report_card/',
    getCurrentUserCompletedInformation: 'give_user_info_report_card/'
  },
}
