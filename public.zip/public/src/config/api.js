const URL = ``


export const api = {
  baseUrl: URL,
}
