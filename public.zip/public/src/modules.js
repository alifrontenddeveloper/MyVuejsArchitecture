import routes from './router/routes'
import apilist from './config/apiList'
import config from './config/config'
import actions from './modules/action'
import { user } from './modules/user'

import css from '!!sass-variable-loader!./assets/sass/bs/bootstrap/_variables.scss'

const modules = {
  routes,
  css,
  apilist,
  config,
  actions,
  $user: user
}
export default modules
