import './assets/sass/bs/_bootstrap.scss'
import './assets/sass/style.scss'
import './assets/icomoon/style.css'
import './modules/utils'
import 'core-js'
import 'babel-polyfill'

import Vue from 'vue'
import App from './App.vue'

import { moment } from './modules/moment'
import './modules/helper'
/**********************************************
 * helpers and tools
 *********************************************/
import Loader from './components/helper/Loader.vue'
import Pagination from './components/helper/Pagination.vue'


Vue.component('Loader', Loader)
Vue.component('Pagination', Pagination)

/*********************************************
 * Routing
 *********************************************/
import { router, VueRouter } from './router/router'

/*********************************************
 * plugins
 *********************************************/
import Modal from './plugins/modal'
import VueBar from 'vuebar'
import VueIziToast from 'vue-izitoast'
import VueClipboard from 'vue-clipboard2'
Vue.use(VueClipboard)
import 'izitoast/dist/css/iziToast.css'
import 'video.js/dist/video-js.css'
/**********************************************
 * Store
 *********************************************/
import { store } from './store/store'
import VueStore from './store/vueStore'
import modules from './modules'
/**********************************************
 * cookie
 *********************************************/
import VueCookie from 'vue-cookie'
/**********************************************
 * Vue Validate
 *********************************************/
import VeeValidate from 'vee-validate'
import { validatorOptions } from './modules/validator'
/**********************************************
 * Vue Directives
 *********************************************/
import directives from './modules/vueDirectives'

Vue.use(Modal)
Vue.use(VueBar)
Vue.use(VueIziToast, {
  rtl: true,
  timeout: 10000
})

Vue.prototype.$moment = moment
Vue.prototype.$parents = function(parentName) {
  parentName = parentName.toLowerCase()
  let parent = this
  const pName = function(vm) {
    if (vm && vm.$options && vm.$options.name) {
      return vm.$options.name.toLowerCase()
    } else {
      return ''
    }
  }
  while (parent && pName(parent) !== parentName) {
    parent = parent.$parent
  }
  return parent
}
Vue.prototype.$baseUrl = window.location.origin

Vue.use(VueStore, modules)
Vue.use(VueCookie)
Vue.use(VueRouter)
/*********************************************
 * FILTERS
 *********************************************/
import filters from './modules/vueFilters'
Vue.use(VeeValidate, validatorOptions)
Vue.filter('date', filters.dateFormat)
Vue.filter('time', filters.timeFormat)

/*********************************************
 * DIRECTIVE
 *********************************************/
Vue.directive('number', directives.number)
/*********************************************
 * THE APP
 *********************************************/
Vue.config.productionTip = false
Vue.config.warnHandler = () => {}
let APP = new Vue({
  el: '#app',
  router,
  store,
  components: {},
  directives: {},
  render: h => h(App)
})
