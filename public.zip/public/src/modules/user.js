const User = {
  data: {
  },

  hasData() {
    return this.data.first_name !== undefined
  },
  resetData() {
    this.data = {
    }
  }
}
export const user = User
