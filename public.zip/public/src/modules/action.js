import modules from '../modules.js'
import {store} from '../store/store'

let actions = {
  loading(val) {
    if (val) {
      store.state.loadingQueue++
    } else {
      setTimeout(() => {
        store.state.loadingQueue--
        if (store.state.loadingQueue < 0) store.state.loadingQueue = 0
      }, 100)
    }
  },
  showRetry(callback, message) {
    modules.state.retry = {
      show: true,
      message,
      onRetry() {
        modules.state.retry = {}
        if (callback && typeof callback === 'function') {
          callback()
        }
      }
    }
  },
  clearToken() {
    modules.settings.clear('token')
    modules.$user.resetData()
    modules.settings.clear('token')
  },
  clearCurrentToken() {
    modules.$user.resetData()
    modules.settings.clear('token')
  },
  getToken() {
    let token = modules.settings.get('token')
    return token
  },
  setToken(token) {
    modules.settings.set('token', token)
  },
  //set uniq key scoped
  setUniqKey(parameter) {
    modules.settings.set('uniqKey', parameter)
  },
  getUniqKey() {
    return modules.settings.get('uniqKey')
  },
  //end uniq key
  getUserInfo(forceUpdate) {
    return new Promise((resolve, reject) => {
      if (forceUpdate || !modules.$user.hasData()) {
        actions.loading(true)
        store.dispatch('dashboard/userDetailAction').then(response => {
          store.commit('dashboard/setUserInfo', response)
          modules.$user.data = response
          actions.loading(false)
          resolve(response)
        })
      }
    })
  },
  clearAllData() {
    modules.$user.resetData()
    this.clearToken()
  },

  checkIsCurrentNumberInSpecialArray(configArrayName, searchNumber) {
    return modules.config[configArrayName].includes(searchNumber)
  }
}
export default actions
