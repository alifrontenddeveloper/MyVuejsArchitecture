import { asyncRequire } from "./modules";
//main dashboard
const Header = asyncRequire("includes/Header");
const RightSidebar = asyncRequire("includes/sidebar/Sidebar");
const RightSidebarOverlay = asyncRequire("includes/sidebar/SidebarOverlay");
const Login = asyncRequire("user/Login");
const Footer = asyncRequire("includes/Footer");
const NotFound = asyncRequire("pages/NotFound");

const getComponents = (def, header, rightSidebar, footer) => {
  let obj = {
    default: def
  };
  if (header !== false) obj.header = Header;
  if (rightSidebar !== false) {
    obj["right-sidebar"] = RightSidebar;
    obj["right-sidebar-o"] = RightSidebarOverlay;
  }
  if (footer !== false) obj["footer"] = Footer;
  return obj;
};
const getRoute = (base, component, name, title, header, sidebar) => {
  return {
    path: base,
    components: getComponents(component, header, sidebar),
    name: name,
    meta: {
      pageTitle: title,
      base: base
    }
  };
};
const getSingleRoute = (base, component, name, title) => {
  return {
    path: base,
    component: component,
    name: name,
    meta: {
      pageTitle: title,
      base: base
    }
  };
};

const routePath = {
  login: "/login/:code?",
  NotFount: "/*"
};

export const routes = [
  getSingleRoute(
    routePath.login,
    Login,
    "login",
    "ورود"),
 
  getSingleRoute(
    routePath.NotFount,
    NotFound,
    "404",
    "404")
];
