import VueRouter from 'vue-router'
import modules from "@/modules";
import {routes} from './routes'

const router = new VueRouter({
  routes,
  mode: 'history',
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    if (to.hash)
      return {
        selector: to.hash
      }
    return {
      x: 0,
      y: 0
    }
  }
})

router.beforeEach((to, from, next) => {
  if (to.meta && to.meta.pageTitle) {
    document.title =
      'تست' + (to.meta.pageTitle ? ' | ' + to.meta.pageTitle : '')
  }

  let token = modules.actions.getToken()
  let needToken = modules.config.noneToken.indexOf(to.name) === -1

  //get current user information
  const getCurrentUserInformation = () => {
    modules.actions.getCurrentUserInformation()
      .then(res => {
        modules.$user.data = res
      })
  }

  //handel redirect user to login route
  const redirectUserToLoginRoute = () => {
    modules.actions.clearToken()
    router.push('/login')
  }
  if (!token && needToken) {
    return to.name !== 'login' ? next(redirectUserToLoginRoute()) : next()
  }
 
  next()
})

export {router, VueRouter}
