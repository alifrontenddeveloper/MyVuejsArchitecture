<template>
  <section class="container-fluid">
    <div class="row">
      <Loader :loading="loading">
        <header-top />
        <Video />
        <rating-comment />
      </Loader>
    </div>
  </section>
</template>

<script>
import HeaderTop from './Header/HeaderTop'
import Video from './Video/Video'
import RatingComment from './RatingComment/RatingComment'
import {mapActions, mapGetters, mapMutations} from 'vuex'

export default {
  name: 'Home',
  components: {
    HeaderTop,
    Video,
    RatingComment
  },
  data() {
    return {
      loading: false,
      day: {},
      owner: {},
      ranking: {}
    }
  },

  computed: {
    ...mapGetters('dashboard', ['getUserDay', 'getUserDayChanged', ''])
  },
  watch: {
    getUserDayChanged(status) {
      this.loading = true
      if (status) this.dayList(this.getUserDay)
    },

  },
  created() {
    this.userDetail()
  },
  methods: {
    ...mapActions('dashboard', ['userDetailAction', 'dayDetailAction']),
    ...mapMutations('dashboard', [
      'setUserLikes',
      'setAllDetails',
      'setOwnerObject',
      'setRankingObject'
    ]),
    // get user details
    userDetail() {
      this.loading = true

      this.userDetailAction().then(res => {
        this.$user.data = res

        if (this.actions.getUserCurrentDayFromStorage())
          this.dayList(this.actions.getUserCurrentDayFromStorage())
        else {
          this.actions.setUserCurrentDayToStorage(res.day)
          this.dayList(res.day)
        }
      })
    },
    // get user current/lastday info
    dayList(dayNumber = 0) {
      this.dayDetailAction({ dayNumber })
        .then(res => {})
        .catch(err => {})
        .finally(() => {
          this.loading = false
        })
    },

  },

}
</script>
