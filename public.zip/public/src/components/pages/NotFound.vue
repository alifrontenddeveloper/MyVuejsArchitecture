<template>
  <div class="page-error">
    <div class="error-number">404</div>
  </div>
</template>

<style lang="scss" scoped>
</style>
