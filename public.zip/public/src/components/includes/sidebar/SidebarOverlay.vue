<template>
  <div class="sidebar-overlay pointer" @click.self="closeSidebar()"></div>
</template>

<script>
import {mapMutations} from "vuex";

export default {
  name: 'SidebarOverlay',
  methods: {
    ...mapMutations('dashboard', ['updateShowSidebarFromChildren']),
    closeSidebar() {
      this.$emit('toggleSidebar')
      this.updateShowSidebarFromChildren(false)
    }
  }
}
</script>
