<template>
  <li :class="[classes, { 'd-none': dNone(item.icon) }]">
    <template v-if="item.items">
      <a href="#" @click.prevent="$emit('toggle')">
        <i :class="item.icon" />
        <!-- <span v-text="item.text" /> -->
      </a>
      <ul>
        <menu-item
          v-for="(itm, j) in item.items"
          :key="j"
          :item="itm"
          @toggle="toggle(itm)"
        />
      </ul>
    </template>
    <router-link v-else :to="item.to">
      <i
        v-if="item.icon"
        :class="[item.icon, { 'd-none': dNone(item.icon) }]"
      />
      <span class="top-curve"></span>
      <span class="bottom-curve"></span>
      <!-- <span v-text="item.text" /> -->
    </router-link>
  </li>
</template>

<script>
import MenuItem from './MenuItem'
import { mapGetters } from 'vuex'

export default {
  name: 'MenuItem',
  components: { MenuItem },
  props: {
    item: { type: Object, default: () => ({}) },
    deep: { type: Number, default: 0 },
  },
  computed: {
    ...mapGetters('dashboard', ['getAllDetails']),

    classes() {
      let item = this.item
      return {
        'has-menu': item.items && item.items.length,
        open: item.open,
        active: item.active,
      }
    },
  },
  methods: {
    dNone(icon) {
      return (
        icon == 'pe-dashboard-icon' &&
        (this.getAllDetails.has_joon == false || this.getAllDetails.is_active == false)
      )
    },
    toggle(item) {
      this.$set(item, 'open', !item.open)
      if (!this.item.items) return
      this.item.items.forEach((m) => {
        if (m !== item) m.open = false
      })
    },
  },
}
</script>