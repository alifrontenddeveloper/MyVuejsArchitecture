<template>
  <aside id="sidebar" ref="sidebar" class="vb-on-left hidden-sm hidden-xs"
         :class="
[$user.data.type === userGuestEnumId ? 'mt-125' : 'mt-50']"
  >
    <div ref="content" class="sidebar-content">
      <section>
        <div class="site-brand">
        </div>

        <nav class="navigation">
          <ul>

            <li v-if="$user.data.type === 100">
              <router-link to="/product">
                <i
                  class="pe-gift"
                />
                <span class="top-curve"></span>
                <span class="bottom-curve"></span>
              </router-link>
            </li>

            <!--new presentation-->
            <li v-if="$user.data.type === 100">
              <router-link to="/presentation">
                <i
                  class="pe-dashboard"
                />
                <span class="top-curve"></span>
                <span class="bottom-curve"></span>
              </router-link>
            </li>
            <!--dashboard-->
            <li v-else>
              <router-link to="/">
                <i
                  v-tooltip.left="'داشبرد'"
                  class="pe-dashboard"
                />
                <span class="top-curve"></span>
                <span class="bottom-curve"></span>
              </router-link>
            </li>
            <!--vacation-->
            <li>
              <router-link to="/vacation">
                <i
                  class="pe-vacation"
                />
                <span class="top-curve"></span>
                <span class="bottom-curve"></span>
              </router-link>
            </li>
            <!--user log out-->
            <li class="mt-5">
              <a @click.prevent="confirmationLogoutUser" class="pointer">
                <i class="pe-logout"></i>
                <span class="top-curve"> </span>
                <span class="bottom-curve"> </span>
              </a>
            </li>
          </ul>
        </nav>
      </section>
    </div>
  </aside>
</template>

<script>
// import MenuItem from './MenuItem'
import {mapActions, mapGetters, mapMutations} from 'vuex'
import modules from "@/modules";

export default {
  name: 'Sidebar',
  data() {
    return {
      userGuestEnumId: modules.config.GuestUser,
      disableBtn: false,
      sticky: false,
      controlUserAccessToPackageCode: false,
      controlUserAccessToCourse: false,
      vbOptions: {
        overrideFloatingScrollbar: true,
        preventParentScroll: true,
        scrollThrottle: 30
      },
      menu: {
        items: [],
        options: {}
      },
      userInfoParameter: {
        first_name: '',
        last_name: '',
        image_url: '',
        mobile: '',
        token: ''
      },
    }
  },
  computed: {
    ...mapGetters('dashboard', ['getAllDetails']),
    isSeenCourseCircle() {
      //show circle is course
      return this.getAllDetails.is_seen_course_guide
    },
    isShowCourseIcon() {
      return this.getAllDetails.show_course_icon
    },
    userOnNegativeDays() {
      return this.getAllDetails.profile_complete
    },
  },
  updated() {
    this.triggerResize()
  },
  mounted() {
    this.checkControlUserAccessToPackageCode()
    // this.checkControlUserAccessToCourse()
    this.triggerResize()
  },
  created() {
    this.getUserInformation()
  },
  methods: {
    ...mapActions('Global', ['logoutAction']),
    ...mapMutations('dashboard', ['setUserInfo']),
    triggerResize(t = 600) {
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'))
      }, t)
    },
    toggle(item) {
      item.open = !item.open
      this.menu.items.forEach(m => {
        if (m !== item) m.open = false
        if (m.items) {
          m.items.forEach(submenu => {
            this.$set(submenu, 'open', false)
          })
        }
      })
    },
    //modal is user logout confirmation
    confirmationLogoutUser() {
      this.$refs.logoutConfirmation.show()
    },
    //log out and remove current user information
    logout() {
      let self = this
      this.disableBtn = true
      this.$refs.logoutConfirmation.close()
      const formData = {
        state: 'exit'
      }

      this.logoutAction({formData})
        .then(result => {
          this.setUserInfo(undefined)
          this.actions.clearAllData()
          this.actions.clearToken()
          this.actions.setUserCurrentDayToStorage(undefined)
          this.actions.setToken(undefined)
          self.disableBtn = false
          self.$router.push('/login')
          // console.log(modules.$user.data, 'user data in log')
        })
        .catch(err => {
          if (err.response.status == 401 || err.response.status == 403) {
            self.$router.push('/login')
          }
        })
    },
    //check user access to package code
    checkControlUserAccessToPackageCode() {
      let currentUserType = modules.actions.getUserInfoFromStorage().type
      if (modules.config.userNotAccessToPackageCode.includes(currentUserType)) {
        this.controlUserAccessToPackageCode = false
      } else {
        this.controlUserAccessToPackageCode = true
      }
    },
    //check user access to course
    checkControlUserAccessToCourse() {
      let currentUserType = modules.actions.getUserInfoFromStorage().type
      if (modules.config.userAccessToCourse.includes(currentUserType)) {
        this.controlUserAccessToCourse = true
      } else {
        this.controlUserAccessToCourse = false
      }
    },
    //request get current user course information
    getUserInformation() {
      this.$store.dispatch('Global/loginToCourse')
        .then(response => {
          this.assignUserInfoParameter(response)
        })
    },
    //assign current user information
    assignUserInfoParameter(data) {
      this.userInfoParameter = {
        first_name: data.first_name,
        last_name: data.last_name,
        image_url: data.image_url,
        mobile: data.mobile,
        token: data.token
      }
    },
    //user accepted feature list dont show again
    acceptViewCourseFeatureList() {
      this.$store.dispatch('Global/courseViewFeatureList').then(response => {
        this.assignNewDataToUserData(response)
        this.$refs.courseFeatureListModal.close()
      })
    },
    assignNewDataToUserData(newUserData) {
      // console.log(newUserData, 'newUserData is user')
      modules.$user.data = newUserData
    },
    //close course modal
    closeFeatureCourse() {
      this.$refs.courseFeatureListModal.close()
    },
    //modal show current user text message understanding redirect to course
    getToCourse() {
      this.$refs.courseFeatureListModal.show()
    },
    //check current user mentoring or presentation
    checkCurrentUserType() {
      return modules.actions.checkIsCurrentNumberInSpecialArray(
        'userPresentation',
        modules.actions.getUserInfoFromStorage().type
      )
    }
  }
}
</script>
