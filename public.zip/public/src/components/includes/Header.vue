<template>
  <header id="header" class="header-content">
    <div class="container-fluid">
      <div class="row d-md-flex align-items-center">
        <div class="col-xs-2 col-sm-5 text-right">
          <div class="d-flex position-relative">
            <i
              class="pe-menu pointer toggle-sidebar d-lg-none"
              @click="$emit('toggleSidebar')"
            />
            <i v-if="!isSeenCourseHelp" class="blink d-lg-none"></i>
          </div>
        </div>
        <div class="col-xs-10 col-sm-7 text-left" >
          <ul class="notification-bar">
            <installment-purchase
              v-if="$user.data.type === 30"
            />
            <notification class="pointer"/>
            <user class="pointer"/>
          </ul>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import User from './child/User'
import InstallmentPurchase from './child/InstallmentPurchase'
import {mapGetters} from 'vuex'
import Notification from './child/Notification';

export default {
  components: {
    User,
    InstallmentPurchase,
    Notification
  },
  data() {
    return {
      loading: false,
      installmentStatus: undefined
    }
  },

  computed: {
    ...mapGetters('dashboard', ['getAllDetails', 'getUserInfo']),
    today() {
      return this.$moment(new Date()).format('jYYYY/jMM/jDD')
    },
    isSeenCourseHelp() {
      return this.getAllDetails.is_seen_course_guide
    }
  },
  methods: {}
}
</script>
