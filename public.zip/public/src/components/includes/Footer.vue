<template>
  <footer id="footer">
    <ul class="socials">
      <li>
        <a href="/" target="_blank">
          <i class="fa fa-youtube-play" />
        </a>
      </li>
      <li>
        <a href="/" target="_blank">
          <i class="fa fa-facebook-official" />
        </a>
      </li>
      <li>
        <a href="/" target="_blank">
          <i class="fa fa-instagram" />
        </a>
      </li>
    </ul>
  </footer>
</template>
