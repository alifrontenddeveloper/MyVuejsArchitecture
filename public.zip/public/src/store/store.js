import Vue from 'vue'
import Vuex from 'vuex'
import login from './modules/login'
import dashboard from './modules/dashboard'

Vue.use(Vuex)

export const store = new Vuex.Store({
  state: {
    loading: false,
    loadingQueue: 0,
    loadingMessages: false,
    retry: {},
    notificationSystem: {
      options: {
        success: {
          position: 'bottomRight',
          timeout: 9000
        },
        error: {
          position: 'bottomRight',
          timeout: 9000
        }
      }
    },
    userInfo: []
  },
  getters: {},
  mutations: {},
  actions: {},
  modules: {
    login,
    dashboard
  }
})
