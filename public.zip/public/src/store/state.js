export default {
    loading: false,
    loadingQueue: 0,
    loadingMessages: false,
    retry: {}
}
