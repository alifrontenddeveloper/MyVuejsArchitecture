import {Axios} from '../../plugins/axios'
import modules from '../../modules'

const state = {
  //is flag used is check current user is login and comparison $user.data.profile_complete
  updateIsUserLogin: false,
}
const getters = {
  getCurrentUserLoginState() {
    return state.updateIsUserLogin
  }
}
const mutations = {
  updateCurrentUserLogin(state, position) {
    state.updateIsUserLogin = position
  }
}
const actions = {
  //run action login
  login({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.login}`, payload)
      .then(response => {
        commit('updateCurrentUserLogin', true)
        return response
      })
  },

  //run action logout
  logout({state, commit}, payload) {
    return new Axios().post(`${modules.apilist.logout}`).then(response => {
      commit('updateCurrentUserLogin', false)
      return response
    })
  },

  //get first video
  getFirstVideo({state, commit}, payload) {
    return new Axios().get(`${modules.apilist.firstVideo}`).then(response => {
      return response
    })
  },

  changePassword({state, commit}, payload) {
    return new Axios()
      .patch(`${modules.apilist.changePassword}`, payload)
      .then(response => {
        return response
      })
  },

  forgetPasswordStepPhone({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.sendCode}`, payload)
      .then(response => {
        return response
      })
  },
  forgetPasswordStepSendCode({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.getCode}`, payload)
      .then(response => {
        return response
      })
  },
  registerCode({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.forgetChangePassword}`, payload)
      .then(response => {
        return response
      })
  },
  autoLogin({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.user.currentUserUniqKeyAutoLogin}${payload}`)
      .then(response => {
        return response
      })
  },

  //presentation new user
  loginUser({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.user.presentationUserGetCode}`, payload)
      .then(response => {
        return response
      })
  },
  acceptedReceivedCode({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.user.presentationUserRegisterCode}`, payload)
      .then(response => {
        return response
      })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
}
