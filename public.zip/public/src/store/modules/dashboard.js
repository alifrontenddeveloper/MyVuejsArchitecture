import {Axios} from '../../plugins/axios'
import modules from '../../modules'

const state = {
  getCommentInfo: false,
  getReportInfo: false,

  userNotif: {},
  notifUpdated: false,
  notificationUpdateFromInVacation: false,
  updateDashboardWithCompletedUserProfile: false,
  updateDashboardWithCompleteUserGuestInformation: false,
  showSidebarFromChildrenToAppControl: false,
  showDashboardContent: false,
  loading: false,
  loadingQueue: 0,
  loadingMessages: false,
  retry: {},
  userInfo: [],
  currentVideoQualities: [],
  cuurentDay: undefined,
  userDayChanged: false,
  relatedDayInfo: false,
  updateUserDay: false,
  allDetails: {},
  dayObject: {},
  ownerObject: {},
  rankingObject: [],
  comments: [],
  // player
  videoLinkChanged: false,
  video: {},
  parnet_comment_count: 0,
  userLikes: [],
  report: {},
  sendingRequest: false
}
const getters = {
  getStateUpdateDashboardWithCompleteUserGuestInformation(state) {
    return state.updateDashboardWithCompleteUserGuestInformation
  },
  getStateUpdateDashboardSyncWithCompletedUserProfileInformation(state) {
    return state.updateDashboardWithCompletedUserProfile
  },
  getGetCommentInfo(state) {
    return state.getCommentInfo
  },
  getUpdateUserDay(state) {
    return state.updateUserDay
  },
  getNotifUpdated(state) {
    return state.notifUpdated
  },
  getUserNotif(state) {
    return state.userNotif
  },

  getGetReportInfo(state) {
    return state.getReportInfo
  },

  getDashboardShowContent(state) {
    return state.showDashboardContent
  },
  getUserLikes(state, getters, rootState, rootGetters) {
    return state.userLikes
  },
  getUserCounts(state, getters, rootState, rootGetters) {
    return state.parnet_comment_count
  },
  getComments: state => {
    return state.comments
  },
  getRelatedDayInfo: state => {
    return state.relatedDayInfo
  },
  getVideo: state => {
    return state.video
  },
  getVideoStatus: state => {
    return state.videoLinkChanged
  },

  // doneTodosCount: (state, getters) => {
  //   return getters.doneTodos.length
  // },
  getUserDay(state) {
    return state.cuurentDay
  },
  getUserDayChanged(state) {
    return state.userDayChanged
  },

  getAllDetails(state) {
    return state.allDetails
  },
  getDayObject(state) {
    return state.dayObject
  },
  getOwnerObject(state) {
    return state.ownerObject
  },
  getRankingObject(state) {
    return state.rankingObject
  },
  getReport(state) {
    return state.report
  },
  getUserInfo() {
    return state.userInfo
  },
  getSendingRequest(state) {
    return state.sendingRequest
  },
  getQualities(state) {
    return state.currentVideoQualities
  },
  getNotificationUpdate(state) {
    return state.notificationUpdateFromInVacation
  }
}
const mutations = {
  updateShowSidebarFromChildren(state, currentFlag) {
    state.showSidebarFromChildrenToAppControl = currentFlag
  },
  updateDashboardWithCompleteGuestUserInformation(state, currentFlag) {
    state.updateDashboardWithCompleteUserGuestInformation = currentFlag
  },
  updateCurrentUserCompletedProfile(state, currentFlagUpdate) {
    state.updateDashboardWithCompletedUserProfile = currentFlagUpdate
  },
  setUpdateUserDay(state, updatePosition) {
    state.updateUserDay = updatePosition
  },
  setUpdateNotification(state, notificationStateUpdate) {
    state.notificationUpdateFromInVacation = notificationStateUpdate
  },
  setNotifUpdated(state, notifUpdated) {
    state.notifUpdated = notifUpdated
  },
  setUserNotif(state, userNotif) {
    state.userNotif = userNotif
  },

  setGetNotificationSelected(state, payload) {
    state.userNotif = payload.userNotif
    state.notifUpdated = payload.updated
  },
  setGetCommentInfo(state, flag = true) {
    state.getCommentInfo = flag
  },
  setGetReportInfo(state, flag = true) {
    state.getReportInfo = flag
  },

  setDashboardShowContent(state, showDashboardContent = true) {
    state.showDashboardContent = showDashboardContent
  },

  setReport(state, result) {
    state.report = result
  },
  setUserLikes(state, result) {
    state.userLikes = result
  },
  setUserCounts(state, parnet_comment_count) {
    state.parnet_comment_count = parnet_comment_count
  },

  setComments(state, result) {
    state.comments = result
  },
  setRelatedDayInfo(state, status = true) {
    state.relatedDayInfo = status
  },
  setVideoStatus(state, videoLinkChanged) {
    state.videoLinkChanged = videoLinkChanged
  },
  setVideo(state, cuurentDay) {
    state.video = {}
    state.video = cuurentDay
  },
  setQualities(state, data) {
    //console.log(data, 'data qualities')
    state.currentVideoQualities = []
    state.currentVideoQualities = data
  },
  setDay(state, cuurentDay) {
    state.cuurentDay = cuurentDay
  },
  setDayChangedStatus(state, dayChanged) {
    state.userDayChanged = dayChanged
  },

  setAllDetails(state, allDetails) {
    state.allDetails = allDetails
  },
  setDayObject(state, dayObject) {
    state.dayObject = dayObject
  },
  setOwnerObject(state, ownerObject) {
    state.ownerObject = ownerObject
  },
  setRankingObject(state, rankingObject) {
    state.rankingObject = rankingObject
  },
  setUserInfo(state, userInfo) {
    state.userInfo = userInfo
  },
  setSendingRequest(state, status) {
    state.sendingRequest = status
  }
}
const actions = {
  //run action dashboard->user detail
  userDetailAction({state, commit, rootState}, payload) {
    return new Axios()
      .get(`${modules.apilist.userDetail}`, payload)
      .then(response => {
        commit('setUserInfo', response)
        return response
      })
  },
  //run action dashboard->day detail
  dayDetailAction({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.dayNum + payload.dayNumber}`)
      .then(response => {
        if (!response.isSuccess) {
          payload.that.actions.clearAllData()
          payload.that.actions.clearToken()
          payload.that.actions.setUserCurrentDayToStorage(undefined)

          payload.that.$router.push('/login')
        } else {
          let likes = []
          // store api data
          commit('setAllDetails', response)

          // store api day data only used in today video list
          commit('setVideo', response.day)

          // store api day data only
          commit('setDayObject', response.day)

          // commit('setSendingRequest', false)

          // store api day number only
          commit('setDay', response.day.day_no)

          // store api likes(used in comments list)
          if (response.like.length > 0) {
            likes = response.like.map(item => {
              return item.object_id
            })
            commit('setUserLikes', likes)
          }

          // store api owner
          commit('setOwnerObject', response.owner)

          // store api ranking
          // commit('setRankingObject', response.ranking)

          // used to get comments if flag is true
          commit('setGetCommentInfo')

          commit('setDashboardShowContent', true)

          // used to get report if flag is true
          commit('setGetReportInfo', true)

          //
          commit('setDayChangedStatus', false)

          commit('setUserCounts', response.parnet_comment_count)

          return response
        }
      })
  },
  //single pin comment
  singleCommentItem({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.comments.pinSingleComment}`, payload)
      .then(response => {
        return response
      })
  },
  //get single pin comment
  getSingleComment({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.comments.pinSingleComment}`)
      .then(response => {
        return response
      })
  },
  dayDetailActionComment({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.dayNum + payload.dayNumber}`)
      .then(response => {
        if (!response.isSuccess) {
          payload.that.actions.clearAllData()
          payload.that.actions.clearToken()
          payload.that.actions.setUserCurrentDayToStorage(undefined)

          payload.that.$router.push('/login')
        } else {
          let likes = []
          // store api data
          commit('setAllDetails', response)
          if (response.like.length > 0) {
            likes = response.like.map(item => {
              return item.object_id
            })
            commit('setUserLikes', likes)
          } else commit('setUserLikes', [])
          commit('setUserCounts', response.parnet_comment_count)
          return response
        }
      })
  },

  //get all feature list information
  getFeatureList() {
    return new Axios()
      .get(`${modules.apilist.feature.list}`)
      .then(response => {
        return response
      })
  },
  //unshow feature list
  unshowFeatureList() {
    return new Axios()
      .get(`${modules.apilist.feature.unshow}`)
      .then(response => {
        return response
      })
  },
  commentList({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.comments.list + payload.urlPostFix}`)
      .then(response => {
        return response
      })
  },
  createCommentAction({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.comments.create}`, payload.data)
      .then(response => {
        commit('setUserCounts', response.parnet_comment_count)

        return response
      })
  },

  likeAction({state, commit}, payload) {
    return new Axios()
      .post(
        `${modules.apilist.comments.like}${payload.id}/like/`,
        payload.likeInfo
      )
      .then(response => {
        return response
      })
  },
  deleteAction({state, commit}, payload) {
    return new Axios().delete(`${payload.url}`).then(response => {
      commit('setUserCounts', response.parnet_comment_count)

      return response
    })
  },
  //********************************************** */
  //Report
  sendReportAction({state, commit}, payload) {
    if (payload.id && payload.id != null && payload.id != '') {
      return new Axios()
        .patch(`${modules.apilist.sendReport}${payload.id}/`, payload.formData)
        .then(response => {
          return response
        })
    } else {
      return new Axios()
        .post(`${modules.apilist.sendReport}`, payload.formData)
        .then(response => {
          return response
        })
    }
  },
  createReport({state, commit}, payload) {
    return new Axios()
      .post('https://mentoring.emrooz.ir/api/additional_report/', payload.formData)
      .then(response => {
        return response
      });
  },

  //reportChecker
  reportSendActions({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.reportChecker}${payload}`)
      .then(response => {
        return response
      })
  },
  updateReport({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.sendReport}${payload}`)
      .then(response => {
        return response
      })
  },
  NotificationIsSeen({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.user.notificationSeen}${payload}/seen/`, {
        is_seen: true
      })
      .then(response => {
        return response
      })
  },
  changeUserImage({state, commit}, payload) {
    return new Axios()
      .post(`${modules.apilist.user.imageCropStart}`, payload)
      .then(response => {
        return response
      })
  },
  confirmUserImageCropper({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.user.confirmUserImageCrop}`, payload)
      .then(response => {
        return response
      })
  },
  //notification counter zero
  NotificationCounterZero({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.user.notificationCounterZero}`)
      .then(response => {
        return response
      })
  },
  //dont show modal user alert joon
  NotShowUserModalIncrementJoon() {
    return new Axios()
      .get(`${modules.apilist.user.joonIncrement}`)
      .then(response => {
        return response
      })
  },
  //list days
  getListDays({state, commit}, payload) {
    return new Axios()
      .get(`${modules.apilist.Days.list}${payload}`)
      .then(response => {
        return response
      })
  },

  //register multi image in single report
  registerMultiImageSingleReport({state, commit}, payload) {
    this.formData = new FormData()
    this.formData.append('file', payload.image)
    return new Axios()
      .post(`${modules.apilist.Report.uploadSingleImage}${payload.type}`, this.formData)
      .then(response => {
        return response
      })
  },
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
}
